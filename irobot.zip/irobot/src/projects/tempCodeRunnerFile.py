from __future__ import annotations

[
    (-0.25, 0.25, -1.05, -0.85),  # OBS-1
    (-0.45, 0.05, 0.10, 0.35),  # OBS-2
    (0.20, 0.55, -0.25, 0.10),  # OBS-3
]
SIGMA0 = np.eye(2) * (0.010**2)
SIGMA_TOTAL_STEP = float(np.sqrt(0.010**2 + 0.020**2))
DT = 0.1
ALPHA = 0.90
FWD_CUTOFF = 7.0
GOAL_TOL = 0.15  # metres — within 15 cm of GOAL counts as reached
GOAL_WINDOW = 2.0  # seconds — look at samples in the last 2 s of each run
# Common arena limits applied to all trajectory panels so both panels are identical in size.
# x range 2.0 m, y range 2.55 m → aspect ratio 1.275 (panels stay compact in a 2-col figure).
_XLIM = (-1.0, 1.0)
_YLIM = (-1.70, 0.85)


# ============================================================
